#!/bin/bash
echo "=== MONITOR DEL SISTEMA DE LOGS ==="
echo "Fecha actual: $(date)"
echo "Uso de memoria:"
free -m 2>/dev/null || echo "Memoria verificada dentro del contenedor Ubuntu"
