#!/bin/bash
if [ $# -eq 0 ]; then
  echo "Error: No ingresaste ningún archivo como argumento."
  echo "Uso correcto: ./analiza.sh <archivo.log>"
  exit 1
fi

if [ ! -f "$1" ]; then
  echo "Error: El archivo '$1' no existe."
  exit 1
fi

echo "Analizando archivo: $1"
echo "Cantidad de líneas: $(wc -l < "$1")"
echo "Cantidad de palabras: $(wc -w < "$1")"
