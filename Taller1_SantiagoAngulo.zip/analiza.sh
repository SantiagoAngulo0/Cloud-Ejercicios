#!/bin/bash

# 1. Verificar si se proporcionó al menos un argumento ($# es la cantidad de argumentos)
if [ $# -eq 0 ]; then
    echo "Error: No ingresaste ningún archivo como argumento."
    echo "Uso correcto: ./analiza.sh <archivo1.log> [archivo2.log ...]"
    exit 1
fi

# Procesar todos los archivos pasados como argumento ($@ representa todos los argumentos)
for archivo in "$@"; do
    echo "========================================="
    
    # 2. Verificar si el archivo existe
    if [ ! -f "$archivo" ]; then
        echo "Error: El archivo '$archivo' no existe."
        continue
    fi

    # 3-8. Mostrar el análisis del archivo
    echo "Analizando archivo: $archivo"
    echo "Cantidad de líneas: $(wc -l < "$archivo")"
    echo "Cantidad de palabras: $(wc -w < "$archivo")"
    echo "Cantidad de caracteres: $(wc -c < "$archivo")"
    echo "Líneas con ERROR: $(grep -c ERROR "$archivo")"
    echo "Líneas con WARN: $(grep -c WARN "$archivo")"
    
done
echo "========================================="
