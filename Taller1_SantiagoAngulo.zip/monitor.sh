#!/bin/bash

echo "===== MONITOR DEL CONTENEDOR ====="
echo "Hostname: $(hostname)"
echo "Usuario: $(whoami)"
echo "Fecha: $(date)"
echo "Directorio: $(pwd)"

echo "===== DISCO ====="
df -h

# Extensión: Validación del uso de disco en la partición principal
uso_disco=$(df / | tail -n 1 | awk '{print $5}' | tr -d '%')

if [ "$uso_disco" -gt 80 ]; then
    echo "¡ADVERTENCIA! El uso de tu disco principal supera el umbral del 80% (Uso actual: $uso_disco%)."
else
    echo "El uso del disco es normal ($uso_disco%)."
fi

echo "===== PROCESOS ====="
echo "Cantidad aproximada de procesos activos: $(ps aux | wc -l)"

echo "===== FIN DEL REPORTE ====="
echo "El diagnóstico terminó correctamente."
